BEGIN TRANSACTION;
CREATE TABLE `acc_driver`(
	`id` CHARACTER( 32 ) PRIMARY KEY NOT null DEFAULT ( hex( randomblob( 16 ) ) ) ,
	`name` CHARACTER( 32 ) NOT null ,
	`title` CHARACTER( 32 ) NOT null
);
CREATE TABLE `acc_item`(
	`id` CHARACTER( 32 ) NOT null PRIMARY KEY DEFAULT ( hex( randomblob( 16 ) ) ) ,
	`driver_id` CHARACTER( 32 ) NOT null DEFAULT 0 REFERENCES `acc_driver`( `id` )
		ON UPDATE CASCADE
		ON DELETE CASCADE ,
	`name` VARYING CHARACTER( 60 ) NOT null DEFAULT 'New account' ,
	`host` VARYING CHARACTER( 100 ) NOT null DEFAULT 'host-name' ,
	`port` UNSIGNED INT( 6 ) NOT null DEFAULT '993' ,
	`login` VARYING CHARACTER( 60 ) null DEFAULT 'anonymous' ,
	`password` VARYING CHARACTER( 60 ) null DEFAULT '' ,
	`path` VARYING CHARACTER( 60 ) NOT null DEFAULT '_dss' ,
	`created` DATETIME NOT null DEFAULT ( datetime( 'now' , 'localtime' ) ) ,
	`active` UNSIGNED TINYINT( 1 ) NOT null DEFAULT 1
);
CREATE TABLE `fs_item`(
	`id` CHARACTER( 32 ) NOT null PRIMARY KEY DEFAULT ( hex( randomblob( 16 ) ) ) ,
	`name` VARYING CHARACTER( 1024 ) ,
	`checksum` CHARACHTER( 32 ) ,
	`created` DATETIME NOT null DEFAULT ( datetime( 'now' , 'localtime' ) ) ,
	`size` unsigned big int(20 ) not null default 0
);
CREATE TABLE `fs_node`(
	`id` CHARACTER( 32 ) NOT null PRIMARY KEY DEFAULT ( hex( randomblob( 16 ) ) ) ,
	`fs_item_id` CHARACTER( 32 ) NOT null REFERENCES `fs_item`( `id` )
		ON UPDATE CASCADE
			ON DELETE CASCADE ,
	`account_id` CHARACTER( 32 ) NOT null REFERENCES `acc_item`( `id` ) 
		ON UPDATE CASCADE
			ON DELETE CASCADE ,
	`fs_node_id` VARYING CHARACTER(255) ,
	`password` CHARACTER( 32 ) NOT null ,
	`created` DATETIME NOT null DEFAULT ( datetime( 'now' , 'localtime' ) )
);
INSERT INTO `acc_item` (id,driver_id,name,host,port,login,password,path,created,active) VALUES ('EA504EFCD4C5B17DB922400C873BD290','DD0D1C003B608D5187C0032E289A024A','Acct 1','imap.yandex.ru',993,'adnim@ashatrov.ru','f2ox9erm','_dsc','2015-11-04 19:50:44',1),
 ('8A35F49CA8DE90886E53AF4B76511BFF','DD0D1C003B608D5187C0032E289A024A','Acct 2','imap.yandex.ru',993,'odmin@ashatrov.ru','f2ox9erm','_dsc','2015-11-04 19:51:44',1);
INSERT INTO `acc_driver` (id,name,title) VALUES ('DD0D1C003B608D5187C0032E289A024A','DriverIMAP4','IMAP v4'),
 ('EBFA26BCBE183F926A8387556AEA74CF','DriverFTP','FTP');
CREATE UNIQUE INDEX uq_fs_node on fs_node( `account_id` , `fs_node_id` ) WHERE ( `fs_node_id` IS NOT null ) ;
COMMIT;
